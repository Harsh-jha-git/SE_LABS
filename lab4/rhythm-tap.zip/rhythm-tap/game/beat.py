import pygame
import random

LANES = 4
LANE_KEYS = [pygame.K_d, pygame.K_f, pygame.K_j, pygame.K_k]
LANE_LABELS = ['D', 'F', 'J', 'K']
LANE_COLORS = [(220,80,80),(80,180,220),(100,220,100),(220,180,60)]

HOLD_FRAMES = 60  # 1 second at 60 FPS

class Note:
    WIDTH = 70
    HEIGHT = 20
    is_hold = False

    def __init__(self, lane, y=-30, speed=4):
        self.lane = lane
        self.y = y
        self.speed = speed
        self.hit = False
        self.missed = False
        self.holding = False
        self.hold_frames = 0

    def update(self):
        self.y += self.speed

    def get_rect(self, lane_x):
        return pygame.Rect(lane_x - self.WIDTH//2, int(self.y), self.WIDTH, self.HEIGHT)

    def head_top(self):
        # Top edge of the part the player has to hit
        return self.y

    def head_y(self):
        # Center of the part the player has to hit
        return self.head_top() + Note.HEIGHT // 2


class HoldNote(Note):
    is_hold = True

    def __init__(self, lane, speed=4):
        # Bar is tall enough that its tail reaches the hit line 1 second after the head does
        self.HEIGHT = int(speed * HOLD_FRAMES) + Note.HEIGHT // 2
        super().__init__(lane, y=-30 - (self.HEIGHT - Note.HEIGHT), speed=speed)
        self.grade = None
        self.pts = 0
        self.col = None

    def head_top(self):
        # The head is the bottom cap of the bar
        return self.y + self.HEIGHT - Note.HEIGHT