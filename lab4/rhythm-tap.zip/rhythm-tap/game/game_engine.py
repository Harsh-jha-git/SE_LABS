import pygame
import random
import math
import array
from game.beat import Note, HoldNote, HOLD_FRAMES, LANES, LANE_KEYS, LANE_LABELS, LANE_COLORS

WIDTH, HEIGHT = 480, 640
FPS = 60
HIT_Y = HEIGHT - 80
HIT_WINDOW = 30
BG = (15, 10, 25)
LANE_W = WIDTH // LANES
HOLD_CHANCE = 0.2      # chance that a spawned note is a hold note
HOLD_LANE_GAP = 120    # keep normal notes out of a lane while a hold bar covers the spawn area
BPM = 120              # one note spawns on every beat
BEAT_INTERVAL = 60.0 / BPM   # seconds per beat
MAX_DT = 0.1           # cap per-frame time step (seconds) so a stall doesn't spawn a burst of notes

def make_hit_sound():
    """Build a short drum-like beep in code (no audio files). Returns None if unsupported."""
    init = pygame.mixer.get_init()
    if not init:
        return None
    freq, fmt, channels = init
    if fmt != -16:  # only 16-bit signed samples are generated here
        return None
    n = int(freq * 0.09)  # ~90 ms
    samples = array.array('h')
    phase = 0.0
    for i in range(n):
        t = i / n
        pitch = 300 - 180 * t          # pitch drops 300 Hz -> 120 Hz for a drum-like thump
        phase += 2 * math.pi * pitch / freq
        envelope = (1 - t) ** 2        # fast decay
        value = int(32767 * 0.5 * envelope * math.sin(phase))
        for _ in range(channels):
            samples.append(value)
    sound = pygame.mixer.Sound(buffer=samples.tobytes())
    sound.set_volume(0.6)
    return sound

class GameEngine:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Rhythm Tap")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("monospace", 26, bold=True)
        self.big_font = pygame.font.SysFont("monospace", 44, bold=True)
        self.hit_sound = make_hit_sound()
        self.reset()

    def reset(self):
        self.notes = []
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.misses = 0
        self.grade_counts = {"PERFECT": 0, "GREAT": 0, "OK": 0}
        self.game_time = 0.0               # seconds of play time (advances only while playing)
        self.next_beat_time = BEAT_INTERVAL  # when the next note is due
        self.speed = 5
        self.frame = 0
        self.feedback = []  # (text, color, ttl, x, y)
        self.game_over = False

    def accuracy(self):
        # (PERFECT + GREAT + OK) / total notes * 100, where total = notes hit + notes missed
        hits = sum(self.grade_counts.values())
        total = hits + self.misses
        return hits / total * 100 if total else 0.0

    def spawn_note(self, overshoot=0.0):
        # Don't put a new note inside a hold bar that still covers the spawn area
        busy = {n.lane for n in self.notes if n.is_hold and n.y < HOLD_LANE_GAP}
        free = [l for l in range(LANES) if l not in busy] or list(range(LANES))
        lane = random.choice(free)
        if random.random() < HOLD_CHANCE:
            note = HoldNote(lane, speed=self.speed)
        else:
            note = Note(lane, y=-30, speed=self.speed)
        # If the beat fell between frames, start the note where it would already be
        note.y += self.speed * FPS * overshoot
        self.notes.append(note)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    self.reset()
                elif not self.game_over:
                    for i, key in enumerate(LANE_KEYS):
                        if event.key == key:
                            self.process_tap(i)
            if event.type == pygame.KEYUP and not self.game_over:
                for i, key in enumerate(LANE_KEYS):
                    if event.key == key:
                        self.process_release(i)
        return True

    def process_tap(self, lane):
        # Find closest note in this lane near hit zone
        best = None
        best_dist = 9999
        for note in self.notes:
            if note.lane == lane and not note.hit and not note.missed and not note.holding:
                dist = abs(note.head_y() - HIT_Y)
                if dist < best_dist:
                    best_dist = dist
                    best = note
        lane_x = lane * LANE_W + LANE_W // 2
        if best and best_dist <= HIT_WINDOW:
            if best_dist < 8:
                grade, pts = "PERFECT", 300
                col = (255, 220, 0)
            elif best_dist < 18:
                grade, pts = "GREAT", 200
                col = (100, 220, 100)
            else:
                grade, pts = "OK", 100
                col = (180, 180, 255)
            if best.is_hold:
                # Head hit: start holding. Score is awarded when the hold completes.
                best.holding = True
                best.hold_frames = 0
                best.grade, best.pts, best.col = grade, pts, col
            else:
                best.hit = True
                self.grade_counts[grade] += 1
                self.combo += 1
                self.max_combo = max(self.max_combo, self.combo)
                self.score += pts * max(1, self.combo // 5)
                self.feedback.append([grade, col, 40, lane_x, HIT_Y - 30])
            if self.hit_sound:
                self.hit_sound.play()
        else:
            self.combo = 0
            self.feedback.append(["MISS", (220,60,60), 40, lane_x, HIT_Y - 30])

    def process_release(self, lane):
        # Letting go of a hold note before it completes is a miss
        lane_x = lane * LANE_W + LANE_W // 2
        for note in self.notes:
            if note.lane == lane and note.holding:
                note.holding = False
                note.missed = True
                self.misses += 1
                self.combo = 0
                self.feedback.append(["MISS", (220,60,60), 40, lane_x, HIT_Y - 30])

    def complete_hold(self, note):
        note.holding = False
        note.hit = True
        self.grade_counts[note.grade] += 1
        self.combo += 1
        self.max_combo = max(self.max_combo, self.combo)
        self.score += note.pts * max(1, self.combo // 5)
        lane_x = note.lane * LANE_W + LANE_W // 2
        self.feedback.append([note.grade, note.col, 40, lane_x, HIT_Y - 30])

    def update(self, dt=0.0):
        if self.game_over: return
        self.frame += 1

        # Beat-based spawning: advance the game clock, spawn a note for every beat that has passed
        self.game_time += min(dt, MAX_DT)
        while self.game_time >= self.next_beat_time:
            self.spawn_note(overshoot=self.game_time - self.next_beat_time)
            self.next_beat_time += BEAT_INTERVAL
            if self.frame % 600 == 0:
                self.speed = min(10, self.speed + 0.5)

        for note in self.notes:
            note.update()
            if note.holding:
                note.hold_frames += 1
                if note.hold_frames >= HOLD_FRAMES:
                    self.complete_hold(note)
            elif not note.hit and not note.missed and note.head_top() > HIT_Y + HIT_WINDOW + Note.HEIGHT:
                note.missed = True
                self.misses += 1
                self.combo = 0

        self.notes = [n for n in self.notes if not (n.hit or n.missed and n.y > HEIGHT + 10)]
        self.feedback = [[t,c,ttl-1,x,y] for t,c,ttl,x,y in self.feedback if ttl > 1]

        if self.misses >= 15:
            self.game_over = True

    def draw_hold(self, note, lx):
        rect = note.get_rect(lx)
        col = LANE_COLORS[note.lane]
        if note.missed:
            col = (90, 90, 100)
        body = tuple(c // 2 for c in col)
        if note.holding:
            # Bar drains into the hit line while held
            body = col
            rect.height = min(rect.height, HIT_Y - rect.y)
            if rect.height <= 0:
                return
        pygame.draw.rect(self.screen, body, rect, border_radius=5)
        pygame.draw.rect(self.screen, (240, 240, 240), rect, 2, border_radius=5)
        if not note.holding:
            cap = pygame.Rect(rect.x, rect.bottom - Note.HEIGHT, Note.WIDTH, Note.HEIGHT)
            pygame.draw.rect(self.screen, col, cap, border_radius=5)

    def draw_summary(self):
        ov = pygame.Surface((WIDTH,HEIGHT), pygame.SRCALPHA)
        ov.fill((0,0,0,200))
        self.screen.blit(ov,(0,0))

        def center(surf, y):
            self.screen.blit(surf, (WIDTH//2 - surf.get_width()//2, y))

        center(self.big_font.render("GAME OVER", True, (220,60,60)), 50)

        rows = [
            ("PERFECT", self.grade_counts["PERFECT"], (255,220,0)),
            ("GREAT",   self.grade_counts["GREAT"],   (100,220,100)),
            ("OK",      self.grade_counts["OK"],      (180,180,255)),
            ("MISS",    self.misses,                  (220,60,60)),
        ]
        y = 140
        for label, count, col in rows:
            name = self.font.render(label, True, col)
            num = self.font.render(str(count), True, col)
            self.screen.blit(name, (110, y))
            self.screen.blit(num, (WIDTH - 110 - num.get_width(), y))
            y += 40

        pygame.draw.line(self.screen, (90,90,110), (100, y + 5), (WIDTH - 100, y + 5), 1)
        center(self.font.render(f"Accuracy: {self.accuracy():.1f}%", True, (255,255,255)), y + 20)
        center(self.font.render(f"Score: {self.score}", True, (200,200,200)), y + 70)
        center(self.font.render(f"Max Combo: {self.max_combo}x", True, (200,200,200)), y + 105)
        center(self.font.render("Press R to Restart", True, (160,160,160)), y + 175)

    def draw(self):
        self.screen.fill(BG)
        # Lane dividers
        for i in range(LANES + 1):
            pygame.draw.line(self.screen, (40,40,60), (i*LANE_W,0), (i*LANE_W,HEIGHT), 1)

        # Hit line
        pygame.draw.line(self.screen, (80,80,100), (0,HIT_Y), (WIDTH,HIT_Y), 2)
        for i in range(LANES):
            lx = i*LANE_W + LANE_W//2
            pygame.draw.rect(self.screen, LANE_COLORS[i],
                pygame.Rect(lx - Note.WIDTH//2, HIT_Y - 12, Note.WIDTH, 24), border_radius=6)
            lbl = self.font.render(LANE_LABELS[i], True, (20,20,20))
            self.screen.blit(lbl, (lx - lbl.get_width()//2, HIT_Y - 10))

        # Notes
        for note in self.notes:
            if note.hit: continue
            lx = note.lane * LANE_W + LANE_W // 2
            if note.is_hold:
                self.draw_hold(note, lx)
                continue
            rect = note.get_rect(lx)
            pygame.draw.rect(self.screen, LANE_COLORS[note.lane], rect, border_radius=5)

        # Feedback
        for text, color, ttl, x, y in self.feedback:
            surf = self.font.render(text, True, color)
            alpha = min(255, ttl * 7)
            surf.set_alpha(alpha)
            self.screen.blit(surf, (x - surf.get_width()//2, y))

        # HUD
        sc = self.font.render(f"Score: {self.score}", True, (220,220,220))
        co = self.font.render(f"Combo: {self.combo}x", True, (255,220,80))
        mi = self.font.render(f"Misses: {self.misses}/15", True, (220,100,100))
        self.screen.blit(sc, (10, 10))
        self.screen.blit(co, (10, 40))
        self.screen.blit(mi, (WIDTH - 170, 10))

        if self.game_over:
            self.draw_summary()
        pygame.display.flip()

    def run(self):
        running = True
        dt = 0.0
        while running:
            running = self.handle_events()
            self.update(dt)
            self.draw()
            dt = self.clock.tick(FPS) / 1000.0   # seconds since the previous frame
        pygame.quit()